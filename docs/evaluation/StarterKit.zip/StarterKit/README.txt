* Modifier le fichier 2023_2024/Eleves_PSIe_2023_2024.xlsx
* ajouter les élèves avec ajout_eleves.py


Modifier le barème et noter les élèves dans le fichier
 * 2023_2024/Eleves_PSIe_2023_2024.xlsx
 (Je note toutes les questions sur 5 et je mets un poids par question (dans la matrice question/compétence)

 * Noter les élèves dans le meme fichier.

Ajouter le DS à l'aide du fichier ajout_ds_PSI.py

Ajoute le DS et crée les fichier individuelle.